package com.cout970.magneticraft.tileentity.electric.generators;

import com.cout970.magneticraft.tileentity.electric.TileElectricBase;

/**
 * Created by cypheraj on 1/14/16.
 */
public class TileCombustionEngine extends TileElectricBase {

}
