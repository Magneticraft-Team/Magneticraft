package com.cout970.magneticraft.tileentity.multiblock;

/**
 * Created by cout970 on 15/01/2016.
 */
public class TileMultiBlockChassis extends TileMultiblockBase {
}
