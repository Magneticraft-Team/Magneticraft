package com.cout970.magneticraft.block.multiblock;

/**
 * Created by cout970 on 15/01/2016.
 */
public class BlockChassis extends BlockMultiBlockBase {
    @Override
    public String getBlockName() {
        return "chassis";
    }
}
