package com.cout970.magneticraft.block;

/**
 * Created by cout970 on 17/01/2016.
 */
public class BlockLimestone extends BlockBase {

    @Override
    public String getBlockName() {
        return "limestone";
    }
}
