package com.cout970.magneticraft.proxy;

/**
 * Created by cout970 on 06/12/2015.
 */
public class CommonProxy {

    public void init() {

    }
}
